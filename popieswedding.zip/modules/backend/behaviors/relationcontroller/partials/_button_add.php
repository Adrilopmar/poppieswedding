<a
    data-control="popup"
    data-handler="onRelationButtonAdd"
    href="javascript:;"
    class="btn btn-sm btn-secondary relation-button-add"
>
    <i class="icon-list-add"></i> <?= e($this->relationGetMessage('buttonAdd')) ?>
</a>
