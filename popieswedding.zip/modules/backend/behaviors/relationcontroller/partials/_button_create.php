<a
    data-control="popup"
    data-handler="onRelationButtonCreate"
    data-request-data="manage_id: null"
    href="javascript:;"
    class="btn btn-sm btn-secondary relation-button-create"
>
    <i class="icon-create"></i> <?= e($this->relationGetMessage('buttonCreate')) ?>
</a>
