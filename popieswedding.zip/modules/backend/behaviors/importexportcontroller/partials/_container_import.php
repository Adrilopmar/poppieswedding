<div class="import-behavior">

    <?= $importUploadFormWidget->render() ?>

    <?php if ($importOptionsFormWidget): ?>
        <?= $importOptionsFormWidget->render() ?>
    <?php endif ?>

</div>
