<div data-control="toolbar">
    <a
        href="javascript:;"
        id="showIgnoredColumnsButton"
        class="btn btn-sm btn-secondary oc-icon-eye disabled"
        onclick="$.oc.importBehavior.showIgnoredColumns()">
        <?= __("Show Ignored Columns") ?>
    </a>
    <a
        href="javascript:;"
        id="autoMatchColumnsButton"
        class="btn btn-sm btn-secondary oc-icon-bullseye"
        onclick="$.oc.importBehavior.autoMatchColumns()">
        <?= __("Auto Match Columns") ?>
    </a>
</div>
