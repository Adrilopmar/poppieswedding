// Deprecated reference
window.assetManager = oc.AssetManager;
window.ocJSON = oc.parseJSON;
