// Importing JavaScript
//

module.exports = [
    "october/october.lang.js",
    "october/october.alert.js",
    "october/october.snackbar.js",
    "october/october.scrollpad.js",
    "october/october.sidenav.js",
    "october/october.scrollbar.js",
    "october/october.filelist.js",
    "october/october.layout.js",
    "october/october.sidepaneltab.js",
    "october/october.simplelist.js",
    "october/october.treelist.js",
    "october/october.sidenav-tree.js",
    "october/october.datetime.js",
    "october/october.responsivemenu.js",
    "october/october.mainmenu.js",
    "october/october.modalfocusmanager.js",
    "october/october.domidmanager.js",
    "october/october.vueutils.js",
    "october/october.tooltip.js",
    "october/october.jsmodule.js",

    // Still used? -sg
    "october/october.flyout.js",
    "october/october.tabformexpandcontrols.js",

    "backend/backend.js",
    "backend/backend.ajax.js",
    "backend/backend.fixes.js",
];
