jQuery(function() {
    $('form input[type=text], form input[type=password]').first().trigger('focus');
});
