<div class="facet-item">
    <input
        name="Filter[value]"
        type="number"
        value="<?= e($scope->value) ?>"
        class="form-control form-control-sm popup-allow-focus w-90"
        autocomplete="off" />
</div>
