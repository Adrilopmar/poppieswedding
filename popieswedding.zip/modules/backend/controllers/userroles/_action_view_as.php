
<div class="field-action">
    <div class="row">
        <div class="col-md-8">
            <h5><?= __("View As Role") ?></h5>
            <p><?= __("This lets you test the actions this role can perform.") ?></p>
        </div>
        <div class="col-md-4">
            <div class="field-action-button">
                <button
                    class="btn btn-secondary"
                    data-request="onImpersonateRole"
                    data-stripe-load-indicator
                >
                    <?= __("View As Role") ?>
                </button>
            </div>
        </div>
    </div>
</div>
