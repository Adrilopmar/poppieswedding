form, fieldset, h5, h6, pre, blockquote, ol, dl, dt, dd, address, dd, dtm, div, td, th, hr {
    margin: 0;
    padding: 0;
}

body {
    background-color: white;
    font: 62.5% Helvetica, Arial, Tahoma, Verdana, Helvetica, sans-serif;
}

p {
    font-size: 12px;
}
