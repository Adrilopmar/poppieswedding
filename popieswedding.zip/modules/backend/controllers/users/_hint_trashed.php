<div class="layout-row min-size">
    <div class="callout callout-danger">
        <div class="header">
            <i class="icon-trash"></i>
            <h3><?= e(trans('backend::lang.user.trashed_hint_title')) ?></h3>
            <p><?= e(trans('backend::lang.user.trashed_hint_desc')) ?></p>
        </div>
    </div>
</div>