View the changelog on the [October CMS website](https://octobercms.com/changelog)
